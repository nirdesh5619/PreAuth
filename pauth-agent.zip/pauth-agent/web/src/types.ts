export type EventType = 'start' | 'token' | 'artifact' | 'end' | 'error'

export type NodeName =
  | 'coordinator'
  | 'document'
  | 'clinical'
  | 'policy'
  | 'matcher'
  | 'hitl'
  | 'assembler'

export type RunEvent = {
  id: string
  run_id: string
  ts: string
  node: NodeName | string
  type: EventType
  payload: Record<string, unknown>
}

export type Artifact = {
  id: string
  node: string
  kind: string
  data: Record<string, unknown>
  updated_at: string
}

export type CaseFile = {
  id: string
  filename: string
  content_type?: string
}

export type RunSummary = {
  id: string
  case_id: string
  status: 'running' | 'interrupted' | 'completed' | 'error' | string
  error: string
  created_at: string
  updated_at: string
  interrupt: Record<string, unknown> | null
  events?: RunEvent[]
  artifacts?: Artifact[]
}

export type CaseRecord = {
  id: string
  patient_initials: string
  payer: string
  plan: string
  procedure: string
  cpt: string
  icd: string
  urgency: string
  notes: string
  created_at: string
  files: CaseFile[]
  latest_run: RunSummary | null
}

export type MatchItem = {
  criterion_id: string
  criterion: string
  status: 'met' | 'missing' | 'conflict'
  rationale: string
  evidence: { doc_id: string; page: number; quote: string }[]
}

export const AGENT_ORDER: NodeName[] = [
  'coordinator',
  'document',
  'clinical',
  'policy',
  'matcher',
  'hitl',
  'assembler',
]

export const AGENT_LABEL: Record<NodeName, string> = {
  coordinator: 'Coordinator',
  document: 'Document',
  clinical: 'Clinical',
  policy: 'Policy',
  matcher: 'Matcher',
  hitl: 'Human review',
  assembler: 'Assembler',
}
