import type { MatchItem } from '../types'

export function matchItemsFrom(data: Record<string, unknown> | undefined): MatchItem[] {
  const items = data?.items
  if (!Array.isArray(items)) return []
  return items as MatchItem[]
}

export function MatchScorecard({
  items,
  summary,
}: {
  items: MatchItem[]
  summary?: string
}) {
  const met = items.filter((item) => item.status === 'met').length
  const missing = items.filter((item) => item.status === 'missing').length
  const conflict = items.filter((item) => item.status === 'conflict').length
  const heading = summary || `${met} met · ${missing} missing · ${conflict} conflict`

  if (!items.length) {
    return <p className="text-sm text-[var(--ink-soft)]">Matcher has not written a scorecard yet.</p>
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-[var(--ink-soft)]">{heading}</p>
      <ul className="grid gap-2 md:grid-cols-2">
        {items.map((item, index) => (
          <li
            key={item.criterion_id || `${item.criterion}-${index}`}
            className="border border-[var(--line)] bg-[var(--paper)] px-3 py-2"
          >
            <p className={`text-[11px] font-semibold uppercase tracking-[0.08em] status-${item.status}`}>
              {item.status}
            </p>
            <p className="mt-1 text-sm">{item.criterion}</p>
            {item.rationale ? (
              <p className="mt-1 text-sm text-[var(--ink-soft)]">{item.rationale}</p>
            ) : null}
          </li>
        ))}
      </ul>
    </div>
  )
}
