import { AGENT_LABEL, type RunEvent } from '../types'
import { matchItemsFrom } from './MatchScorecard'

export function EventTimeline({
  events,
  filter,
  onFilter,
}: {
  events: RunEvent[]
  filter: string
  onFilter: (value: string) => void
}) {
  const visible = filter === 'all' ? events : events.filter((event) => event.node === filter)
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center justify-between gap-3 border-b border-[var(--line)] px-[18px] py-3">
        <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--ink-soft)]">Trace</p>
        <select
          value={filter}
          onChange={(event) => onFilter(event.target.value)}
          className="bg-transparent text-xs text-[var(--ink-soft)] outline-none"
        >
          <option value="all">All agents</option>
          {Object.entries(AGENT_LABEL).map(([id, label]) => (
            <option key={id} value={id}>
              {label}
            </option>
          ))}
        </select>
      </div>
      <ol className="min-h-0 flex-1 overflow-auto px-4 py-3 font-mono text-[11px] leading-5">
        {visible.length === 0 ? (
          <li className="text-[var(--ink-soft)]">Waiting for the coordinator to dispatch.</li>
        ) : (
          visible.map((event) => (
            <li key={event.id} className="grid grid-cols-[64px_1fr] gap-2 py-1.5">
              <time className="text-[var(--ink-soft)]">
                {new Date(event.ts).toLocaleTimeString([], { hour12: false })}
              </time>
              <div>
                <span className="text-[var(--copper-deep)]">{event.node}</span>
                <span className="text-[var(--ink-soft)]"> {event.type}</span>
                <EventDetail event={event} />
              </div>
            </li>
          ))
        )}
      </ol>
    </div>
  )
}

function EventDetail({ event }: { event: RunEvent }) {
  if (event.type === 'artifact' && event.payload.kind === 'match') {
    const data = (event.payload.data as Record<string, unknown> | undefined) || {}
    const items = matchItemsFrom(data)
    const summary = String(data.summary ?? '')
    return (
      <p className="mt-1 text-[10px] text-[var(--ink-soft)]">
        {summary || `${items.length} criteria written`}. Open the scorecard in Human review.
      </p>
    )
  }
  if (event.type !== 'end' && event.type !== 'error') return null
  const payload = event.payload
  if (event.node === 'matcher' && event.type === 'end') {
    return (
      <p className="mt-1 text-[10px] text-[var(--ink-soft)]">
        {String(payload.met ?? 0)} met · {String(payload.missing ?? 0)} missing · {String(payload.conflict ?? 0)}{' '}
        conflict (event counts, not the table)
      </p>
    )
  }
  return (
    <pre className="mt-1 whitespace-pre-wrap text-[10px] text-[var(--ink-soft)]">
      {JSON.stringify(payload, null, 0)}
    </pre>
  )
}
