import { type FormEvent } from 'react'
import { MatchScorecard } from './MatchScorecard'
import type { MatchItem } from '../types'

export function HitlPanel({
  items,
  summary,
  busy,
  onSubmit,
}: {
  items: MatchItem[]
  summary?: string
  busy: boolean
  onSubmit: (form: FormData) => Promise<void>
}) {
  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const submitter = (event.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null
    if (submitter?.value) {
      form.set('status', submitter.value)
    }
    await onSubmit(form)
  }

  const open = items.filter((item) => item.status === 'missing' || item.status === 'conflict').length

  return (
    <section className="col-span-full border-t border-[var(--line)] bg-[var(--paper-2)] px-6 py-5">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.1em] text-[var(--copper-deep)]">
            Human review
          </p>
          <h2 className="display mt-1 text-[28px] leading-none">The graph is waiting on you</h2>
        </div>
        <p className="text-sm text-[var(--ink-soft)]">
          {open ? `${open} criteria still open.` : 'All listed criteria are marked met.'}
        </p>
      </div>
      <div className="mb-5 max-h-[320px] overflow-auto">
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.08em] text-[var(--ink-soft)]">
          Scorecard
        </p>
        <MatchScorecard items={items} summary={summary} />
      </div>
      <form className="grid gap-4 md:grid-cols-[1fr_220px_auto]" onSubmit={handleSubmit}>
        <div className="field">
          <label htmlFor="notes">Reviewer notes</label>
          <textarea id="notes" name="notes" rows={3} placeholder="Optional sign-off, or what is still missing." />
        </div>
        <div className="field">
          <label htmlFor="files">Attach more chart files</label>
          <input
            id="files"
            name="files"
            type="file"
            multiple
            accept=".pdf,.txt,.md,application/pdf,text/plain,text/markdown"
          />
        </div>
        <div className="flex flex-col justify-end gap-2">
          <button type="submit" name="status" value="approved" className="btn btn-copper" disabled={busy}>
            Approve packet
          </button>
          <button type="submit" name="status" value="changes" className="btn btn-ghost" disabled={busy}>
            Send back
          </button>
        </div>
      </form>
    </section>
  )
}
