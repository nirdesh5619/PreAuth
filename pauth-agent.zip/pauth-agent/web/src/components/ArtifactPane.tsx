import { AGENT_LABEL, type Artifact, type NodeName } from '../types'
import { MatchScorecard, matchItemsFrom } from './MatchScorecard'

export function ArtifactPane({
  node,
  artifacts,
}: {
  node: NodeName | null
  artifacts: Artifact[]
}) {
  const selected = node
    ? artifacts.filter((item) => item.node === node)
    : artifacts.slice(-1)
  const artifact = selected[selected.length - 1]
  const title = node === 'matcher' ? 'Matcher scorecard' : node ? AGENT_LABEL[node] : 'Latest artifact'

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="panel-h">{title}</div>
      <div className="min-h-0 flex-1 overflow-auto px-5 py-4">
        {!artifact ? (
          <p className="text-sm text-[var(--ink-soft)]">
            Select a node after it finishes to read what it produced.
          </p>
        ) : (
          <ArtifactBody kind={artifact.kind} data={artifact.data} />
        )}
      </div>
    </div>
  )
}

function ArtifactBody({ kind, data }: { kind: string; data: Record<string, unknown> }) {
  if (kind === 'match') {
    return <MatchScorecard items={matchItemsFrom(data)} summary={String(data.summary ?? '')} />
  }

  if (kind === 'review') {
    const match = (data.match_result as Record<string, unknown> | undefined) || {}
    return (
      <MatchScorecard items={matchItemsFrom(match)} summary={String(match.summary ?? '')} />
    )
  }

  if (kind === 'policy') {
    const items = (data.items as { id: string; text: string }[]) || []
    return (
      <div>
        <p className="display text-2xl">{String(data.title ?? data.policy_id ?? 'Policy')}</p>
        <p className="mt-1 text-sm text-[var(--ink-soft)]">
          {String(data.payer ?? '')} · {String(data.source ?? '')}
        </p>
        <ol className="mt-4 list-decimal space-y-2 pl-4 text-sm">
          {items.map((item) => (
            <li key={item.id}>{item.text}</li>
          ))}
        </ol>
      </div>
    )
  }

  if (kind === 'clinical') {
    const diagnoses = (data.diagnoses as string[]) || []
    const failed = (data.failed_therapies as string[]) || []
    return (
      <dl className="space-y-3 text-sm">
        <div>
          <dt className="text-xs uppercase tracking-[0.08em] text-[var(--ink-soft)]">Diagnoses</dt>
          <dd>{diagnoses.join(', ') || '—'}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-[0.08em] text-[var(--ink-soft)]">Failed therapies</dt>
          <dd>{failed.join(', ') || '—'}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-[0.08em] text-[var(--ink-soft)]">Severity</dt>
          <dd>{String(data.severity || '—')}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-[0.08em] text-[var(--ink-soft)]">History</dt>
          <dd className="whitespace-pre-wrap text-[var(--ink-soft)]">{String(data.history || '')}</dd>
        </div>
      </dl>
    )
  }

  if (kind === 'packet') {
    return (
      <article>
        <p className="display text-2xl">{String(data.title ?? 'Packet')}</p>
        <pre className="mt-4 whitespace-pre-wrap font-[var(--ui)] text-sm leading-6">
          {String(data.markdown ?? '')}
        </pre>
      </article>
    )
  }

  if (kind === 'documents') {
    const sections = (data.sections as { heading: string; text: string }[]) || []
    return (
      <div className="space-y-4">
        {sections.map((section) => (
          <section key={section.heading}>
            <h3 className="text-sm font-semibold">{section.heading}</h3>
            <p className="mt-1 whitespace-pre-wrap text-sm text-[var(--ink-soft)]">{section.text}</p>
          </section>
        ))}
      </div>
    )
  }

  return (
    <pre className="whitespace-pre-wrap font-mono text-[11px] text-[var(--ink-soft)]">
      {JSON.stringify(data, null, 2)}
    </pre>
  )
}
