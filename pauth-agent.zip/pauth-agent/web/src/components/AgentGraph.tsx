import { useMemo } from 'react'
import {
  Background,
  Handle,
  Position,
  ReactFlow,
  type Edge,
  type Node,
  type NodeProps,
} from '@xyflow/react'
import { AGENT_LABEL, type NodeName, type RunEvent } from '../types'

type Status = 'idle' | 'running' | 'done' | 'error' | 'waiting'

function statusFromEvents(events: RunEvent[], node: NodeName, runStatus: string): Status {
  const mine = events.filter((event) => event.node === node)
  if (mine.some((event) => event.type === 'error')) return 'error'
  if (mine.some((event) => event.type === 'end')) return 'done'
  if (mine.some((event) => event.type === 'start')) return 'running'
  if (node === 'hitl' && runStatus === 'interrupted') return 'waiting'
  return 'idle'
}

type AgentData = { status: Status; label: string }
type AgentNodeType = Node<AgentData, 'agent'>

function AgentNode({ data }: NodeProps<AgentNodeType>) {
  const status = data.status
  const label = data.label
  return (
    <div className="agent-node" data-status={status}>
      <Handle type="target" position={Position.Top} style={{ opacity: 0 }} />
      <p className="text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)]">{status}</p>
      <p className="mt-1 text-[15px] font-semibold leading-tight">{label}</p>
      <Handle type="source" position={Position.Bottom} style={{ opacity: 0 }} />
    </div>
  )
}

const nodeTypes = { agent: AgentNode }

const LAYOUT: { id: NodeName; x: number; y: number }[] = [
  { id: 'coordinator', x: 250, y: 8 },
  { id: 'document', x: 16, y: 130 },
  { id: 'clinical', x: 250, y: 130 },
  { id: 'policy', x: 484, y: 130 },
  { id: 'matcher', x: 250, y: 252 },
  { id: 'hitl', x: 250, y: 374 },
  { id: 'assembler', x: 250, y: 496 },
]

const EDGE_DEFS: [NodeName, NodeName][] = [
  ['coordinator', 'document'],
  ['coordinator', 'clinical'],
  ['coordinator', 'policy'],
  ['document', 'matcher'],
  ['clinical', 'matcher'],
  ['policy', 'matcher'],
  ['matcher', 'hitl'],
  ['hitl', 'assembler'],
]

export function AgentGraph({
  events,
  runStatus,
  selected,
  onSelect,
}: {
  events: RunEvent[]
  runStatus: string
  selected: NodeName | null
  onSelect: (id: NodeName) => void
}) {
  const nodes = useMemo<AgentNodeType[]>(() => {
    return LAYOUT.map((item) => ({
      id: item.id,
      type: 'agent',
      position: { x: item.x, y: item.y },
      data: {
        label: AGENT_LABEL[item.id],
        status: statusFromEvents(events, item.id, runStatus),
      },
      selected: selected === item.id,
      draggable: false,
    }))
  }, [events, runStatus, selected])

  const edges = useMemo<Edge[]>(() => {
    return EDGE_DEFS.map(([source, target]) => {
      const srcStatus = statusFromEvents(events, source, runStatus)
      return {
        id: `${source}-${target}`,
        source,
        target,
        data: { status: srcStatus },
      }
    })
  }, [events, runStatus])

  return (
    <div className="h-full min-h-[520px]">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        panOnDrag
        zoomOnScroll={false}
        nodesConnectable={false}
        elementsSelectable
        onNodeClick={(_, node) => onSelect(node.id as NodeName)}
        proOptions={{ hideAttribution: true }}
      >
        <Background gap={22} size={1} color="oklch(0.86 0.016 80)" />
      </ReactFlow>
    </div>
  )
}
