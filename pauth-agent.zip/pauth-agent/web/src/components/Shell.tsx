import { NavLink, Outlet } from 'react-router-dom'

export function Shell() {
  return (
    <div className="min-h-svh">
      <header className="flex h-16 items-center justify-between border-b border-[var(--line)] px-6">
        <NavLink to="/" className="flex items-baseline gap-3">
          <span className="display text-[28px] leading-none">Folio</span>
          <span className="text-xs uppercase tracking-[0.14em] text-[var(--ink-soft)]">
            Prior authorization
          </span>
        </NavLink>
        <nav className="flex items-center gap-3">
          <NavLink to="/" className="text-sm text-[var(--ink-soft)] hover:text-[var(--ink)]">
            Cases
          </NavLink>
          <NavLink to="/new" className="btn btn-copper text-sm">
            New case
          </NavLink>
        </nav>
      </header>
      <Outlet />
    </div>
  )
}
