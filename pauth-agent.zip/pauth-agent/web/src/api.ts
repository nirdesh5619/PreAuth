import type { CaseRecord, RunSummary } from './types'

async function parse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const text = await res.text()
    throw new Error(text || res.statusText)
  }
  return res.json() as Promise<T>
}

export async function listCases(): Promise<CaseRecord[]> {
  const data = await parse<{ cases: CaseRecord[] }>(await fetch('/api/cases'))
  return data.cases
}

export async function getCase(id: string): Promise<CaseRecord> {
  return parse<CaseRecord>(await fetch(`/api/cases/${id}`))
}

export async function getRun(id: string): Promise<RunSummary> {
  return parse<RunSummary>(await fetch(`/api/runs/${id}`))
}

export async function createCase(form: FormData): Promise<{ case: CaseRecord; run: RunSummary }> {
  return parse(await fetch('/api/cases', { method: 'POST', body: form }))
}

export async function resumeRun(runId: string, form: FormData): Promise<{ run: RunSummary }> {
  return parse(await fetch(`/api/runs/${runId}/resume`, { method: 'POST', body: form }))
}

export async function getPacket(runId: string): Promise<{ title: string; markdown: string; summary: string }> {
  return parse(await fetch(`/api/runs/${runId}/packet`))
}
