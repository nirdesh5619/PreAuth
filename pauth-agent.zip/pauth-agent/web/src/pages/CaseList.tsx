import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { listCases } from '../api'
import type { CaseRecord } from '../types'

export function CaseList() {
  const [cases, setCases] = useState<CaseRecord[] | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    listCases()
      .then(setCases)
      .catch((err: Error) => setError(err.message))
  }, [])

  return (
    <main className="mx-auto w-full max-w-5xl px-6 py-10">
      <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[var(--ink-soft)]">Workbench</p>
      <h1 className="display mt-2 text-[40px] leading-none">Open cases</h1>
      <p className="mt-3 max-w-xl text-[var(--ink-soft)]">
        Each case is a single prior-auth thread: specialists run in parallel, you review the gaps, then Folio drafts the letter.
      </p>
      {error ? <p className="mt-6 text-[var(--conflict)]">{error}</p> : null}
      {cases && cases.length === 0 ? (
        <div className="mt-10 border border-[var(--line)] bg-[var(--paper-2)] px-6 py-10">
          <p className="display text-3xl">No folders yet</p>
          <p className="mt-2 text-[var(--ink-soft)]">Start with initials, payer, and a procedure. Attach notes if you have them.</p>
          <Link to="/new" className="btn btn-copper mt-6 inline-flex">
            Open a case
          </Link>
        </div>
      ) : (
        <ul className="mt-10 divide-y divide-[var(--line)] border-y border-[var(--line)]">
          {(cases ?? []).map((item) => (
            <li key={item.id}>
              <Link to={`/cases/${item.id}`} className="flex items-baseline justify-between gap-4 py-4 hover:bg-[var(--paper-2)]">
                <div>
                  <p className="display text-[28px] leading-none">{item.patient_initials}</p>
                  <p className="mt-2 text-sm text-[var(--ink-soft)]">
                    {item.payer} {item.plan ? `· ${item.plan}` : ''} · {item.procedure}
                  </p>
                </div>
                <span className="pill" data-tone={item.latest_run?.status ?? 'idle'}>
                  {item.latest_run?.status ?? 'unstarted'}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </main>
  )
}
