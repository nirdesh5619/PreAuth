import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { getCase, getPacket, getRun, resumeRun } from '../api'
import { AgentGraph } from '../components/AgentGraph'
import { ArtifactPane } from '../components/ArtifactPane'
import { EventTimeline } from '../components/EventTimeline'
import { HitlPanel } from '../components/HitlPanel'
import { matchItemsFrom } from '../components/MatchScorecard'
import type { Artifact, CaseRecord, NodeName, RunEvent, RunSummary } from '../types'

export function CaseRun() {
  const { caseId } = useParams()
  const [caseRecord, setCaseRecord] = useState<CaseRecord | null>(null)
  const [run, setRun] = useState<RunSummary | null>(null)
  const [events, setEvents] = useState<RunEvent[]>([])
  const [artifacts, setArtifacts] = useState<Artifact[]>([])
  const [selected, setSelected] = useState<NodeName | null>('coordinator')
  const [filter, setFilter] = useState('all')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const runId = caseRecord?.latest_run?.id

  useEffect(() => {
    if (!caseId) return
    getCase(caseId)
      .then(setCaseRecord)
      .catch((err: Error) => setError(err.message))
  }, [caseId])

  useEffect(() => {
    if (!runId) return
    const id = runId
    let cancelled = false
    async function refresh() {
      const data = await getRun(id)
      if (cancelled) return
      setRun(data)
      setEvents(data.events ?? [])
      setArtifacts(data.artifacts ?? [])
    }
    refresh().catch((err: Error) => setError(err.message))
    const source = new EventSource(`/api/runs/${id}/events`)
    source.onmessage = (message) => {
      const event = JSON.parse(message.data) as RunEvent
      setEvents((current) => {
        if (current.some((item) => item.id === event.id)) return current
        return [...current, event]
      })
      if (event.type === 'artifact' || event.type === 'end') {
        getRun(id)
          .then((data) => {
            setRun(data)
            setArtifacts(data.artifacts ?? [])
          })
          .catch(() => undefined)
      }
    }
    const timer = window.setInterval(() => {
      refresh().catch(() => undefined)
    }, 1500)
    return () => {
      cancelled = true
      source.close()
      window.clearInterval(timer)
    }
  }, [runId])

  const matchArtifact = artifacts.find((item) => item.kind === 'match' || item.node === 'matcher')
  const scorecard = useMemo(() => {
    const fromArtifact = matchItemsFrom(matchArtifact?.data)
    if (fromArtifact.length) {
      return {
        items: fromArtifact,
        summary: String(matchArtifact?.data.summary ?? ''),
      }
    }
    const interrupt = run?.interrupt as { match_result?: Record<string, unknown> } | null
    const fromInterrupt = matchItemsFrom(interrupt?.match_result)
    return {
      items: fromInterrupt,
      summary: String(interrupt?.match_result?.summary ?? ''),
    }
  }, [matchArtifact, run?.interrupt])

  useEffect(() => {
    if (scorecard.items.length && selected === 'coordinator') {
      setSelected('matcher')
    }
  }, [scorecard.items.length, selected])

  const packet = artifacts.find((item) => item.kind === 'packet')

  async function onResume(form: FormData) {
    if (!runId) return
    setBusy(true)
    try {
      await resumeRun(runId, form)
      const data = await getRun(runId)
      setRun(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Resume failed')
    } finally {
      setBusy(false)
    }
  }

  async function downloadPacket() {
    if (!runId) return
    const data = await getPacket(runId)
    const blob = new Blob([data.markdown], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'letter-of-medical-necessity.md'
    link.click()
    URL.revokeObjectURL(url)
  }

  if (!caseRecord) {
    return (
      <main className="px-6 py-10">
        <p className="text-[var(--ink-soft)]">{error || 'Opening case…'}</p>
      </main>
    )
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--line)] px-6 py-4">
        <div>
          <Link to="/" className="text-xs uppercase tracking-[0.12em] text-[var(--ink-soft)]">
            All cases
          </Link>
          <h1 className="display mt-1 text-[32px] leading-none">
            {caseRecord.patient_initials}
            <span className="ml-3 text-[18px] text-[var(--ink-soft)]">
              {caseRecord.payer} · {caseRecord.procedure}
            </span>
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <span className="pill" data-tone={run?.status ?? 'running'}>
            {run?.status ?? 'running'}
          </span>
          {packet ? (
            <button type="button" className="btn btn-ghost text-sm" onClick={downloadPacket}>
              Download letter
            </button>
          ) : null}
        </div>
      </div>
      {error ? <p className="px-6 py-2 text-sm text-[var(--conflict)]">{error}</p> : null}
      <div className="workbench">
        <section className="panel">
          <div className="panel-h">Graph</div>
          <div className="h-[calc(100svh-220px)] min-h-[480px]">
            <AgentGraph
              events={events}
              runStatus={run?.status ?? 'running'}
              selected={selected}
              onSelect={setSelected}
            />
          </div>
        </section>
        <section className="panel">
          <ArtifactPane node={selected} artifacts={artifacts} />
        </section>
        <section className="panel">
          <EventTimeline events={events} filter={filter} onFilter={setFilter} />
        </section>
        {run?.status === 'interrupted' ? (
          <HitlPanel items={scorecard.items} summary={scorecard.summary} busy={busy} onSubmit={onResume} />
        ) : null}
      </div>
    </div>
  )
}
