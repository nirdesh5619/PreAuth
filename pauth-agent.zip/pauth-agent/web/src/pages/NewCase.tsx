import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { createCase } from '../api'

const SAMPLE = `Patient: A.R., 54
Moderately to severely active seropositive rheumatoid arthritis for 6 years.
Failed methotrexate 20 mg weekly for 16 weeks due to persistent synovitis.
IGRA (Quantiferon) negative on 2026-07-12.
No active infection.
Plan: infliximab 3 mg/kg IV. HCPCS J1745. ICD M05.9.`

export function NewCase() {
  const navigate = useNavigate()
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setBusy(true)
    setError('')
    try {
      const created = await createCase(new FormData(event.currentTarget))
      navigate(`/cases/${created.case.id}`)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create case')
      setBusy(false)
    }
  }

  return (
    <main className="mx-auto w-full max-w-3xl px-6 py-10">
      <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[var(--ink-soft)]">Intake</p>
      <h1 className="display mt-2 text-[40px] leading-none">Open a prior auth</h1>
      <p className="mt-3 text-[var(--ink-soft)]">
        Initials only. The graph will read notes and attachments; you will still sign off before a letter is assembled.
      </p>
      <form className="mt-8 grid gap-5" onSubmit={onSubmit}>
        <div className="grid gap-5 md:grid-cols-2">
          <div className="field">
            <label htmlFor="patient_initials">Patient initials</label>
            <input id="patient_initials" name="patient_initials" required placeholder="A.R." defaultValue="A.R." />
          </div>
          <div className="field">
            <label htmlFor="urgency">Urgency</label>
            <select id="urgency" name="urgency" defaultValue="routine">
              <option value="routine">Routine</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>
          <div className="field">
            <label htmlFor="payer">Payer</label>
            <input id="payer" name="payer" required defaultValue="Aetna" />
          </div>
          <div className="field">
            <label htmlFor="plan">Plan</label>
            <input id="plan" name="plan" defaultValue="PPO" />
          </div>
          <div className="field md:col-span-2">
            <label htmlFor="procedure">Procedure or drug</label>
            <input id="procedure" name="procedure" required defaultValue="Infliximab infusion" />
          </div>
          <div className="field">
            <label htmlFor="cpt">CPT / HCPCS</label>
            <input id="cpt" name="cpt" defaultValue="J1745" />
          </div>
          <div className="field">
            <label htmlFor="icd">ICD</label>
            <input id="icd" name="icd" defaultValue="M05.9" />
          </div>
        </div>
        <div className="field">
          <label htmlFor="notes">Clinical notes</label>
          <textarea id="notes" name="notes" rows={8} defaultValue={SAMPLE} />
        </div>
        <div className="field">
          <label htmlFor="files">Attachments</label>
          <input
            id="files"
            name="files"
            type="file"
            multiple
            accept=".pdf,.txt,.md,application/pdf,text/plain,text/markdown"
            className="drop"
          />
          <p className="text-xs text-[var(--ink-soft)]">PDF, text, or markdown. Dummy PDFs live in backend/pauth/fixtures/attachments.</p>
        </div>
        {error ? <p className="text-sm text-[var(--conflict)]">{error}</p> : null}
        <div className="flex justify-end">
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Dispatching…' : 'Run agents'}
          </button>
        </div>
      </form>
    </main>
  )
}
